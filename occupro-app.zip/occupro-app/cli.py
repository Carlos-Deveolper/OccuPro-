"""
OccuPro — cli.py - Command-line interface for the Career Demand database.

Examples:
    python cli.py top                       Show the 15 highest-demand careers
    python cli.py top --n 25                Show the top 25
    python cli.py bottom                    Show the 15 lowest-demand careers
    python cli.py search nurse              Search by title keyword
    python cli.py category "Healthcare Support"   List a category
    python cli.py categories                List all categories
    python cli.py education "Bachelor's degree"   Filter by typical education
    python cli.py show 29-1141              Show full detail for a SOC code
"""

import argparse
import sqlite3
from pathlib import Path

from demand_calculator import demand_label

DB_PATH = Path(__file__).parent / "career_demand.db"


def connect():
    if not DB_PATH.exists():
        raise SystemExit("Database not found. Run `python build_database.py` first.")
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def print_table(rows):
    if not rows:
        print("No results.")
        return
    print(f"{'Title':<45} {'Category':<28} {'Demand':>7} {'Growth%':>8} {'Wage':>10}")
    print("-" * 102)
    for r in rows:
        wage = f"${r['median_wage']:,}" if r['median_wage'] else "N/A"
        print(f"{r['title']:<45.45} {r['category']:<28.28} "
              f"{r['demand_index']:>6.1f}  {r['pct_change']:>+7.1f}% {wage:>10}")


def cmd_top(args):
    conn = connect()
    rows = conn.execute(
        "SELECT * FROM occupations ORDER BY demand_index DESC LIMIT ?", (args.n,)
    ).fetchall()
    print_table(rows)


def cmd_bottom(args):
    conn = connect()
    rows = conn.execute(
        "SELECT * FROM occupations ORDER BY demand_index ASC LIMIT ?", (args.n,)
    ).fetchall()
    print_table(rows)


def cmd_search(args):
    conn = connect()
    rows = conn.execute(
        "SELECT * FROM occupations WHERE title LIKE ? ORDER BY demand_index DESC",
        (f"%{args.keyword}%",),
    ).fetchall()
    print_table(rows)


def cmd_category(args):
    conn = connect()
    rows = conn.execute(
        "SELECT * FROM occupations WHERE category = ? ORDER BY demand_index DESC",
        (args.name,),
    ).fetchall()
    print_table(rows)


def cmd_categories(args):
    conn = connect()
    rows = conn.execute(
        "SELECT category, COUNT(*) n, ROUND(AVG(demand_index),1) avg_demand "
        "FROM occupations GROUP BY category ORDER BY avg_demand DESC"
    ).fetchall()
    print(f"{'Category':<35} {'# occ.':>7} {'Avg demand':>11}")
    print("-" * 55)
    for r in rows:
        print(f"{r['category']:<35} {r['n']:>7} {r['avg_demand']:>11.1f}")


def cmd_education(args):
    conn = connect()
    rows = conn.execute(
        "SELECT * FROM occupations WHERE typical_education = ? ORDER BY demand_index DESC",
        (args.level,),
    ).fetchall()
    print_table(rows)


def cmd_show(args):
    conn = connect()
    r = conn.execute("SELECT * FROM occupations WHERE soc_code = ?", (args.soc_code,)).fetchone()
    if not r:
        print("Not found.")
        return
    wage = f"${r['median_wage']:,}" if r['median_wage'] else "Not published"
    if r['median_wage'] and r['wage_topcoded']:
        wage = f">= ${r['median_wage']:,} (BLS top-codes wages above this)"
    print(f"\n{r['title']}  (SOC {r['soc_code']})")
    print(f"Category: {r['category']}")
    print(f"Period: {r['period']}")
    print(f"Employment: {r['employment_start']:,.1f}k -> {r['employment_end']:,.1f}k "
          f"({r['pct_change']:+.1f}%)")
    print(f"Annual openings: {r['annual_openings']:,.1f}k/yr "
          f"({r['openings_rate_pct']:.1f}% of current workforce, replaced/added yearly)")
    print(f"Median annual wage: {wage}")
    print(f"Typical entry education: {r['typical_education']}")
    print(f"Related work experience needed: {r['work_experience']}")
    print(f"On-the-job training: {r['on_job_training']}")
    print(f"\nCareer Demand Index: {r['demand_index']} / 100  -  {demand_label(r['demand_index'])}")
    print(f"  (growth component: {r['growth_score']}, openings component: {r['openings_score']})")
    print(f"\nMore detail (real official sources, not scraped into this tool):")
    print(f"  O*NET profile:      https://www.onetonline.org/link/summary/{r['soc_code']}.00")
    print(f"  BLS OOH search:     https://www.bls.gov/ooh/search.htm?q={r['title'].replace(' ', '+')}")
    print(f"  CareerOneStop cert: https://www.careeronestop.org/Toolkit/Training/find-certifications.aspx")
    print(f"  Regional wages:     https://www.careeronestop.org/Toolkit/Wages/find-salary.aspx")
    print(f"  School ROI/debt:    https://collegescorecard.ed.gov/search\n")


def main():
    parser = argparse.ArgumentParser(description="OccuPro — query the Career Demand database.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("top", help="Show highest-demand careers")
    p.add_argument("--n", type=int, default=15)
    p.set_defaults(func=cmd_top)

    p = sub.add_parser("bottom", help="Show lowest-demand careers")
    p.add_argument("--n", type=int, default=15)
    p.set_defaults(func=cmd_bottom)

    p = sub.add_parser("search", help="Search by title keyword")
    p.add_argument("keyword")
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("category", help="List occupations in a category")
    p.add_argument("name")
    p.set_defaults(func=cmd_category)

    p = sub.add_parser("categories", help="List all categories with averages")
    p.set_defaults(func=cmd_categories)

    p = sub.add_parser("education", help="Filter by typical entry education")
    p.add_argument("level")
    p.set_defaults(func=cmd_education)

    p = sub.add_parser("show", help="Full detail for a single SOC code")
    p.add_argument("soc_code")
    p.set_defaults(func=cmd_show)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
