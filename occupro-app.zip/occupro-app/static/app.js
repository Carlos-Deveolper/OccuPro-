const els = {
  search: document.getElementById('searchInput'),
  category: document.getElementById('categorySelect'),
  education: document.getElementById('educationSelect'),
  sort: document.getElementById('sortSelect'),
  body: document.getElementById('resultsBody'),
  meta: document.getElementById('resultsMeta'),
  heroStats: document.getElementById('heroStats'),
  modalOverlay: document.getElementById('modalOverlay'),
  modalTitle: document.getElementById('modalTitle'),
  modalCode: document.getElementById('modalCode'),
  modalBody: document.getElementById('modalBody'),
  modalClose: document.getElementById('modalClose'),
  compareModalOverlay: document.getElementById('compareModalOverlay'),
  compareModalBody: document.getElementById('compareModalBody'),
  compareModalSub: document.getElementById('compareModalSub'),
  compareModalClose: document.getElementById('compareModalClose'),
  compareBar: document.getElementById('compareBar'),
  compareChips: document.getElementById('compareChips'),
  clearCompareBtn: document.getElementById('clearCompareBtn'),
  openCompareBtn: document.getElementById('openCompareBtn'),
  filterToggle: document.getElementById('filterToggle'),
  controlsPanel: document.getElementById('controlsPanel'),
  toastContainer: document.getElementById('toastContainer'),
  printArea: document.getElementById('printArea'),
  expChart: document.getElementById('expChart'),
};

let ROWS_CACHE = [];        // currently visible (rendered) rows
let FILTERED_ROWS = [];     // full filtered/sorted result set for the current query
let ALL_ROWS = [];          // full unfiltered dataset, loaded once
const COMPARE = new Map();  // soc_code -> row object, max 4
const MAX_COMPARE = 4;
const PAGE_SIZE = 50;
let visibleCount = PAGE_SIZE;
const loadMoreWrap = document.getElementById('loadMoreWrap');
const loadMoreBtn = document.getElementById('loadMoreBtn');

/* ---------------------------- Toasts ---------------------------- */
function showToast(message, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  els.toastContainer.appendChild(el);
  setTimeout(() => {
    el.classList.add('leaving');
    setTimeout(() => el.remove(), 220);
  }, 3000);
}

/* ---------------------------- Formatting ---------------------------- */
function gaugeColor(score) {
  if (score >= 65) return '#10B981';
  if (score >= 35) return '#F59E0B';
  return '#DC2626';
}
function renderGauge(score) {
  const color = gaugeColor(score);
  return `
    <div class="gauge">
      <div class="gauge-track">
        <div class="gauge-fill" style="width:0%; background:${color};" data-target="${score}"></div>
      </div>
      <div class="gauge-label"><span style="color:${color}">${score.toFixed(1)}</span><span>/100</span></div>
    </div>`;
}
function animateGauges(root = document) {
  requestAnimationFrame(() => {
    root.querySelectorAll('.gauge-fill[data-target]').forEach(el => {
      el.style.width = el.dataset.target + '%';
    });
  });
}
function formatWage(r) {
  if (!r.median_wage) return 'Not published';
  const prefix = r.wage_topcoded ? '\u2265 ' : '';
  return `${prefix}$${r.median_wage.toLocaleString()}`;
}
function onetUrl(soc) { return `https://www.onetonline.org/link/summary/${soc}.00`; }
function oohSearchUrl(title) { return `https://www.bls.gov/ooh/search.htm?q=${encodeURIComponent(title)}`; }

/* ---------------------------- Loading skeleton ---------------------------- */
function renderSkeleton(rows = 8) {
  const cols = 8;
  els.body.innerHTML = Array.from({ length: rows }).map(() => `
    <tr class="skeleton-row">
      ${Array.from({ length: cols }).map(() => `<td><div class="skeleton-bar" style="width:${40 + Math.random()*50}%"></div></td>`).join('')}
    </tr>`).join('');
}

/* ---------------------------- Compare ---------------------------- */
function toggleCompare(row, checked) {
  if (checked) {
    if (COMPARE.size >= MAX_COMPARE) {
      showToast(`You can compare up to ${MAX_COMPARE} careers at a time.`, 'error');
      const cb = document.querySelector(`input.compare-checkbox[data-soc="${row.soc_code}"]`);
      if (cb) cb.checked = false;
      return;
    }
    COMPARE.set(row.soc_code, row);
    showToast(`Added "${row.title}" to compare (${COMPARE.size}/${MAX_COMPARE})`, 'success');
  } else {
    COMPARE.delete(row.soc_code);
  }
  renderCompareBar();
  syncCompareCheckboxes();
}

function syncCompareCheckboxes() {
  document.querySelectorAll('input.compare-checkbox').forEach(cb => {
    cb.checked = COMPARE.has(cb.dataset.soc);
    cb.disabled = !cb.checked && COMPARE.size >= MAX_COMPARE;
  });
}

function renderCompareBar() {
  if (COMPARE.size === 0) {
    els.compareBar.classList.remove('visible');
    return;
  }
  els.compareBar.classList.add('visible');
  els.compareChips.innerHTML = [...COMPARE.values()].map(r => `
    <span class="compare-chip">${r.title}<button data-soc="${r.soc_code}" aria-label="Remove">×</button></span>
  `).join('');
  els.compareChips.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
      COMPARE.delete(btn.dataset.soc);
      renderCompareBar();
      syncCompareCheckboxes();
    });
  });
  els.openCompareBtn.textContent = `Compare Selected (${COMPARE.size})`;
}

els.clearCompareBtn.addEventListener('click', () => {
  COMPARE.clear();
  renderCompareBar();
  syncCompareCheckboxes();
  showToast('Comparison cleared', 'info');
});

function metricRow(label, values, formatter, higherIsBetter = true) {
  const nums = values.map(v => (typeof v === 'number' ? v : null));
  const valid = nums.filter(v => v !== null);
  const best = valid.length ? (higherIsBetter ? Math.max(...valid) : Math.min(...valid)) : null;
  const cells = values.map((v, i) => {
    const isWinner = valid.length > 1 && nums[i] === best;
    return `<td class="${isWinner ? 'winner' : ''}">${formatter(v)}</td>`;
  }).join('');
  return `<tr><td class="metric-label">${label}</td>${cells}</tr>`;
}

els.openCompareBtn.addEventListener('click', () => {
  if (COMPARE.size < 2) {
    showToast('Select at least 2 careers to compare.', 'error');
    return;
  }
  const rows = [...COMPARE.values()];
  els.compareModalSub.textContent = `${rows.length} careers selected`;

  const header = `<tr><th></th>${rows.map(r => `<th>${r.title}<div style="font-weight:400;font-size:0.72rem;color:#64748B;margin-top:0.2rem;">${r.soc_code}</div></th>`).join('')}</tr>`;

  const body = [
    metricRow('Category', rows.map(r => r.category), v => v, false),
    metricRow('Demand Index', rows.map(r => r.demand_index), v => `${v.toFixed(1)} / 100`),
    metricRow('Median wage', rows.map(r => r.median_wage), (v, r) => v ? formatWage({median_wage:v, wage_topcoded:0}) : 'Not published'),
    metricRow('10-yr projected growth', rows.map(r => r.pct_change), v => `${v>=0?'+':''}${v.toFixed(1)}%`),
    metricRow('Annual openings', rows.map(r => r.annual_openings), v => `${v.toLocaleString()}k/yr`),
    metricRow('Openings rate', rows.map(r => r.openings_rate_pct), v => `${v.toFixed(1)}%`),
    metricRow('Typical education', rows.map(r => r.typical_education), v => v, false),
    metricRow('Work experience needed', rows.map(r => r.work_experience), v => v, false),
    metricRow('On-the-job training', rows.map(r => r.on_job_training), v => v, false),
  ].join('');

  els.compareModalBody.innerHTML = `
    <div class="compare-table-wrap">
      <table class="compare-table">
        <thead>${header}</thead>
        <tbody>${body}</tbody>
      </table>
    </div>
    <div style="display:flex; gap:0.6rem; margin-top:1.3rem; flex-wrap:wrap;">
      <button class="btn btn-primary" id="printCompareBtn">🖨 Print this comparison</button>
      <button class="btn btn-ghost" id="closeCompareBtn2">Close</button>
    </div>
    <div class="modal-honesty" style="margin-top:1rem;">
      Highlighted cells show the higher/better real BLS-sourced figure among your
      selected careers for that row. This reflects the data shown, not a
      recommendation — always weigh it against your own goals and circumstances.
    </div>
  `;
  document.getElementById('printCompareBtn').addEventListener('click', () => printCompare(rows));
  document.getElementById('closeCompareBtn2').addEventListener('click', closeCompareModal);

  els.compareModalOverlay.classList.add('open');
});

function closeCompareModal() { els.compareModalOverlay.classList.remove('open'); }
els.compareModalClose.addEventListener('click', closeCompareModal);
els.compareModalOverlay.addEventListener('click', (e) => { if (e.target === els.compareModalOverlay) closeCompareModal(); });

/* ---------------------------- Single detail modal ---------------------------- */
function openModal(r) {
  els.modalTitle.textContent = r.title;
  els.modalCode.textContent = `SOC ${r.soc_code} · ${r.category} · ${r.period}`;

  els.modalBody.innerHTML = `
    <div class="modal-grid">
      <div class="modal-stat"><div class="modal-stat-label">Employment now → 2034</div>
        <div class="modal-stat-value">${r.employment_start.toLocaleString()}k → ${r.employment_end.toLocaleString()}k</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Projected growth</div>
        <div class="modal-stat-value" style="color:${r.pct_change>=0?'#059669':'#DC2626'}">${r.pct_change>=0?'+':''}${r.pct_change.toFixed(1)}%</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Annual openings</div>
        <div class="modal-stat-value">${r.annual_openings.toLocaleString()}k/yr</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Openings rate</div>
        <div class="modal-stat-value">${r.openings_rate_pct.toFixed(1)}%</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Median annual wage</div>
        <div class="modal-stat-value">${formatWage(r)}</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Demand Index</div>
        <div class="modal-stat-value" style="color:${gaugeColor(r.demand_index)}">${r.demand_index.toFixed(1)} / 100</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Typical education</div>
        <div class="modal-stat-value" style="font-size:0.92rem">${r.typical_education}</div></div>
      <div class="modal-stat"><div class="modal-stat-label">Related work experience</div>
        <div class="modal-stat-value" style="font-size:0.92rem">${r.work_experience}</div></div>
      <div class="modal-stat"><div class="modal-stat-label">On-the-job training</div>
        <div class="modal-stat-value" style="font-size:0.92rem">${r.on_job_training}</div></div>
    </div>

    <div class="modal-section-title">Go deeper (real official sources)</div>
    <div class="modal-links">
      <a class="modal-link" href="${onetUrl(r.soc_code)}" target="_blank" rel="noopener">
        <span><strong>O*NET profile</strong> — required certifications, tools, skills, related jobs</span>
        <span class="modal-link-arrow">→</span>
      </a>
      <a class="modal-link" href="${oohSearchUrl(r.title)}" target="_blank" rel="noopener">
        <span><strong>BLS Occupational Outlook Handbook</strong> — full narrative profile</span>
        <span class="modal-link-arrow">→</span>
      </a>
      <a class="modal-link" href="https://www.careeronestop.org/Toolkit/Wages/find-salary.aspx" target="_blank" rel="noopener">
        <span><strong>CareerOneStop</strong> — regional / state-level wages and demand</span>
        <span class="modal-link-arrow">→</span>
      </a>
      <a class="modal-link" href="https://www.careeronestop.org/Toolkit/Training/find-certifications.aspx" target="_blank" rel="noopener">
        <span><strong>CareerOneStop Certification Finder</strong> — licenses & certifications by field</span>
        <span class="modal-link-arrow">→</span>
      </a>
      <a class="modal-link" href="https://collegescorecard.ed.gov/search" target="_blank" rel="noopener">
        <span><strong>U.S. Dept. of Education College Scorecard</strong> — real earnings & debt by school and major</span>
        <span class="modal-link-arrow">→</span>
      </a>
      <a class="modal-link" href="https://nces.ed.gov/ipeds/use-the-data" target="_blank" rel="noopener">
        <span><strong>NCES IPEDS</strong> — how many students complete this field of study nationally</span>
        <span class="modal-link-arrow">→</span>
      </a>
    </div>

    <div style="margin-top:1.2rem;">
      <button class="btn btn-primary" id="printSingleBtn">🖨 Print this career</button>
    </div>

    <div class="modal-honesty">
      <strong>What's not shown, on purpose:</strong> a precise "probability of hire within 6 months,"
      a ranked list of "best" schools by ROI, or an AI-automation-risk score. None of these have a
      reliable, free, occupation-level public dataset behind them — the automation-risk figures you'll
      see cited elsewhere mostly trace back to a single 2013 academic study (Frey &amp; Osborne) that's now
      over a decade old, and "best school" rankings by ROI would mean inventing numbers. Real,
      up-to-date versions of that data exist behind paid tools (e.g. Lightcast) or the government
      sources linked above — this tool links out rather than guessing.
    </div>
  `;
  document.getElementById('printSingleBtn').addEventListener('click', () => printSingle(r));
  els.modalOverlay.classList.add('open');
}
function closeModal() { els.modalOverlay.classList.remove('open'); }
els.modalClose.addEventListener('click', closeModal);
els.modalOverlay.addEventListener('click', (e) => { if (e.target === els.modalOverlay) closeModal(); });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeModal(); closeCompareModal(); }
});

/* ---------------------------- Print ---------------------------- */
function printHeader() {
  return `
    <div class="print-header">
      <span class="brand-name">OccuPro</span>
    </div>
    <div class="print-meta">Generated ${new Date().toLocaleDateString()} · Source: U.S. Bureau of Labor Statistics, Employment Projections (2024–2034)</div>
  `;
}
function printDisclaimer() {
  return `<div class="print-disclaimer">This report is for general informational purposes only and does not
    guarantee employment, admission, salary, or any career outcome. The Demand Index is an independently
    derived metric, not an official government statistic. See OccuPro's full disclaimer for details.</div>`;
}
function printSingle(r) {
  els.printArea.innerHTML = `
    ${printHeader()}
    <h2>${r.title} <span style="font-weight:400;color:#64748B;font-size:0.8em;">(SOC ${r.soc_code})</span></h2>
    <table class="print-table">
      <tr><th>Category</th><td>${r.category}</td></tr>
      <tr><th>Demand Index</th><td>${r.demand_index.toFixed(1)} / 100</td></tr>
      <tr><th>Median annual wage</th><td>${formatWage(r)}</td></tr>
      <tr><th>Projected growth (${r.period})</th><td>${r.pct_change>=0?'+':''}${r.pct_change.toFixed(1)}%</td></tr>
      <tr><th>Annual openings</th><td>${r.annual_openings.toLocaleString()}k/yr (${r.openings_rate_pct.toFixed(1)}% of workforce)</td></tr>
      <tr><th>Typical education</th><td>${r.typical_education}</td></tr>
      <tr><th>Work experience needed</th><td>${r.work_experience}</td></tr>
      <tr><th>On-the-job training</th><td>${r.on_job_training}</td></tr>
    </table>
    ${printDisclaimer()}
  `;
  window.print();
}
function printCompare(rows) {
  const metricDefs = [
    ['Category', r => r.category],
    ['Demand Index', r => `${r.demand_index.toFixed(1)} / 100`],
    ['Median wage', r => formatWage(r)],
    ['Projected growth', r => `${r.pct_change>=0?'+':''}${r.pct_change.toFixed(1)}%`],
    ['Annual openings', r => `${r.annual_openings.toLocaleString()}k/yr`],
    ['Openings rate', r => `${r.openings_rate_pct.toFixed(1)}%`],
    ['Typical education', r => r.typical_education],
    ['Work experience', r => r.work_experience],
    ['On-the-job training', r => r.on_job_training],
  ];
  els.printArea.innerHTML = `
    ${printHeader()}
    <h2>Career Comparison</h2>
    <table class="print-table">
      <tr><th></th>${rows.map(r => `<th>${r.title}</th>`).join('')}</tr>
      ${metricDefs.map(([label, fn]) => `<tr><th>${label}</th>${rows.map(r => `<td>${fn(r)}</td>`).join('')}</tr>`).join('')}
    </table>
    ${printDisclaimer()}
  `;
  window.print();
}

/* ---------------------------- Mobile filter drawer ---------------------------- */
els.filterToggle.addEventListener('click', () => {
  els.controlsPanel.classList.toggle('open');
  const open = els.controlsPanel.classList.contains('open');
  els.filterToggle.textContent = open ? '✕ Close Filters' : '☰ Filters & Search';
});

/* ---------------------------- Experience vs Salary chart ---------------------------- */
function renderExperienceChart(rows) {
  const order = ['None', 'Less than 5 years', '5 years or more'];
  const buckets = {};
  order.forEach(k => buckets[k] = []);
  rows.forEach(r => {
    if (r.median_wage && buckets[r.work_experience] !== undefined) {
      buckets[r.work_experience].push(r.median_wage);
    }
  });
  const data = order.map(label => {
    const vals = buckets[label];
    const avg = vals.length ? vals.reduce((a,b) => a+b, 0) / vals.length : 0;
    return { label, avg, n: vals.length };
  });
  const max = Math.max(...data.map(d => d.avg), 1);

  els.expChart.innerHTML = data.map(d => `
    <div class="chart-row">
      <div class="chart-row-label">${d.label === 'None' ? 'No experience required' : d.label}</div>
      <div class="chart-track"><div class="chart-fill" data-target="${(d.avg/max*100).toFixed(1)}" style="width:0%"></div></div>
      <div class="chart-row-value">$${Math.round(d.avg).toLocaleString()}</div>
    </div>
  `).join('');
  requestAnimationFrame(() => {
    els.expChart.querySelectorAll('.chart-fill').forEach(el => { el.style.width = el.dataset.target + '%'; });
  });
}

/* ---------------------------- Render table (paginated) ---------------------------- */
function renderRows(rows) {
  FILTERED_ROWS = rows;
  visibleCount = Math.min(PAGE_SIZE, rows.length);
  renderVisible();
}

function renderVisible() {
  const rows = FILTERED_ROWS.slice(0, visibleCount);
  ROWS_CACHE = rows;
  els.body.innerHTML = rows.map((r, i) => {
    const growthClass = r.pct_change >= 0 ? 'growth-pos' : 'growth-neg';
    const sign = r.pct_change >= 0 ? '+' : '';
    return `
      <tr class="card-row" style="animation-delay:${Math.min(i,20)*12}ms">
        <td class="col-compare">
          <input type="checkbox" class="compare-checkbox" data-soc="${r.soc_code}"
            ${COMPARE.has(r.soc_code) ? 'checked' : ''}
            ${!COMPARE.has(r.soc_code) && COMPARE.size >= MAX_COMPARE ? 'disabled' : ''}
            aria-label="Add ${r.title} to compare">
        </td>
        <td class="col-title">
          <span class="occ-title">${r.title}</span>
          <span class="occ-code">${r.soc_code} · ${r.period}</span>
        </td>
        <td class="col-category">${r.category}</td>
        <td class="col-edu">${r.typical_education}</td>
        <td class="col-wage">${formatWage(r)}</td>
        <td class="col-growth ${growthClass}">${sign}${r.pct_change.toFixed(1)}%</td>
        <td class="col-demand">${renderGauge(r.demand_index)}</td>
        <td><button class="details-btn" data-idx="${i}">Details</button></td>
      </tr>`;
  }).join('');

  els.body.querySelectorAll('.details-btn').forEach(btn => {
    btn.addEventListener('click', () => openModal(ROWS_CACHE[parseInt(btn.dataset.idx, 10)]));
  });
  els.body.querySelectorAll('.compare-checkbox').forEach(cb => {
    cb.addEventListener('change', () => {
      const row = ROWS_CACHE.find(r => r.soc_code === cb.dataset.soc) || ALL_ROWS.find(r => r.soc_code === cb.dataset.soc);
      toggleCompare(row, cb.checked);
    });
  });
  animateGauges();

  const remaining = FILTERED_ROWS.length - visibleCount;
  if (remaining > 0) {
    loadMoreWrap.classList.remove('hidden');
    loadMoreBtn.textContent = `Load more careers (${remaining} more)`;
  } else {
    loadMoreWrap.classList.add('hidden');
  }
  els.meta.textContent = `Showing ${rows.length} of ${FILTERED_ROWS.length} occupation${FILTERED_ROWS.length === 1 ? '' : 's'}`;
}

loadMoreBtn.addEventListener('click', () => {
  visibleCount = Math.min(visibleCount + PAGE_SIZE, FILTERED_ROWS.length);
  renderVisible();
});

/* ---------------------------- Data loading (overridden per build) ---------------------------- */
async function loadOccupations() {
  renderSkeleton();
  const params = new URLSearchParams();
  if (els.search.value.trim()) params.set('q', els.search.value.trim());
  if (els.category.value) params.set('category', els.category.value);
  if (els.education.value) params.set('education', els.education.value);
  params.set('sort', els.sort.value);
  params.set('dir', 'desc');

  try {
    const res = await fetch(`/api/occupations?${params.toString()}`);
    if (!res.ok) throw new Error('Request failed');
    const rows = await res.json();
    renderRows(rows);
  } catch (err) {
    els.body.innerHTML = '';
    els.meta.textContent = '';
    showToast('Could not load occupations. Please try again.', 'error');
  }
}

async function loadFilters() {
  try {
    const [cats, edus] = await Promise.all([
      fetch('/api/categories').then(r => r.json()),
      fetch('/api/education-levels').then(r => r.json()),
    ]);
    cats.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.category;
      opt.textContent = `${c.category} (${c.n})`;
      els.category.appendChild(opt);
    });
    edus.forEach(e => {
      if (!e.typical_education) return;
      const opt = document.createElement('option');
      opt.value = e.typical_education;
      opt.textContent = e.typical_education;
      els.education.appendChild(opt);
    });
  } catch (err) {
    showToast('Could not load filter options.', 'error');
  }
}

async function loadHeroStats() {
  try {
    const rows = await fetch('/api/occupations').then(r => r.json());
    ALL_ROWS = rows;
    const cats = await fetch('/api/categories').then(r => r.json());
    const avgGrowth = rows.reduce((s, r) => s + r.pct_change, 0) / rows.length;
    const nums = els.heroStats.querySelectorAll('.stat-num');
    nums[0].textContent = rows.length;
    nums[1].textContent = `${avgGrowth >= 0 ? '+' : ''}${avgGrowth.toFixed(1)}%`;
    nums[2].textContent = cats.length;
    renderExperienceChart(rows);
  } catch (err) {
    showToast('Could not load summary stats.', 'error');
  }
}

let searchDebounce;
els.search.addEventListener('input', () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(loadOccupations, 250);
});
[els.category, els.education, els.sort].forEach(el => {
  el.addEventListener('change', () => loadOccupations());
});

loadFilters().then(loadOccupations);
loadHeroStats();
