"""
build_database.py

Builds career_demand.db (SQLite) from data/seed_data.py (which loads the
full BLS dataset from data/occupations.json), computing the Career Demand
Index for every occupation via demand_calculator.

Usage:
    python build_database.py
"""

import sqlite3
from pathlib import Path

from data.seed_data import OCCUPATIONS
from demand_calculator import calculate_demand

DB_PATH = Path(__file__).parent / "career_demand.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS occupations (
    soc_code            TEXT PRIMARY KEY,
    title               TEXT NOT NULL,
    category            TEXT NOT NULL,
    employment_start    REAL,
    employment_end      REAL,
    period               TEXT,
    pct_change           REAL,
    annual_openings      REAL,
    openings_rate_pct    REAL,
    median_wage          INTEGER,
    wage_topcoded        INTEGER,
    typical_education    TEXT,
    work_experience      TEXT,
    on_job_training      TEXT,
    growth_score         REAL,
    openings_score       REAL,
    demand_index         REAL
);
CREATE INDEX IF NOT EXISTS idx_category ON occupations(category);
CREATE INDEX IF NOT EXISTS idx_demand ON occupations(demand_index);
"""


def build():
    DB_PATH.unlink(missing_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)

    rows = []
    for occ in OCCUPATIONS:
        result = calculate_demand(
            pct_change=occ["pct_change"],
            annual_openings=occ["annual_openings"],
            employment_start=occ["employment_start"],
        )
        rows.append((
            occ["soc_code"], occ["title"], occ["category"],
            occ["employment_start"], occ["employment_end"], occ["period"],
            occ["pct_change"], occ["annual_openings"], result.openings_rate,
            occ.get("median_wage"), int(bool(occ.get("wage_topcoded"))),
            occ["typical_education"],
            occ["work_experience"], occ["on_job_training"],
            result.growth_score, result.openings_score, result.demand_index,
        ))

    conn.executemany(
        """INSERT INTO occupations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        rows,
    )
    conn.commit()
    conn.close()
    print(f"Built {DB_PATH} with {len(rows)} occupations.")


if __name__ == "__main__":
    build()

