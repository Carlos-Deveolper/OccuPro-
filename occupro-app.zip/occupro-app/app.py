"""
app.py - Flask web app for OccuPro (Career Demand Explorer).

Run with:
    python build_database.py   # once, or whenever data/seed_data.py changes
    python app.py
Then open http://127.0.0.1:5000
"""

import sqlite3
from pathlib import Path
from flask import Flask, jsonify, render_template, request

DB_PATH = Path(__file__).parent / "career_demand.db"

app = Flask(__name__)


def query_db(sql, args=()):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/occupations")
def api_occupations():
    """Supports ?q=keyword&category=X&education=Y&sort=demand_index&dir=desc"""
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    education = request.args.get("education", "").strip()
    sort = request.args.get("sort", "demand_index")
    direction = "DESC" if request.args.get("dir", "desc") == "desc" else "ASC"

    allowed_sorts = {
        "demand_index", "pct_change", "median_wage", "title",
        "annual_openings", "openings_rate_pct",
    }
    if sort not in allowed_sorts:
        sort = "demand_index"

    sql = "SELECT * FROM occupations WHERE 1=1"
    args = []
    if q:
        sql += " AND title LIKE ?"
        args.append(f"%{q}%")
    if category:
        sql += " AND category = ?"
        args.append(category)
    if education:
        sql += " AND typical_education = ?"
        args.append(education)
    sql += f" ORDER BY {sort} {direction}"

    return jsonify(query_db(sql, args))


@app.route("/api/categories")
def api_categories():
    return jsonify(query_db(
        "SELECT category, COUNT(*) as n, ROUND(AVG(demand_index),1) as avg_demand "
        "FROM occupations GROUP BY category ORDER BY avg_demand DESC"
    ))


@app.route("/api/education-levels")
def api_education_levels():
    return jsonify(query_db(
        "SELECT DISTINCT typical_education FROM occupations ORDER BY typical_education"
    ))


@app.route("/api/occupation/<path:soc_code>")
def api_occupation_detail(soc_code):
    rows = query_db("SELECT * FROM occupations WHERE soc_code = ?", (soc_code,))
    if not rows:
        return jsonify({"error": "not found"}), 404
    return jsonify(rows[0])


if __name__ == "__main__":
    if not DB_PATH.exists():
        raise SystemExit("Database not found. Run `python build_database.py` first.")
    app.run(debug=True)
