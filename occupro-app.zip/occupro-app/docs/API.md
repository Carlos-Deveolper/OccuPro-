# API Documentation

Base URL (local dev): `http://127.0.0.1:5000`

All endpoints are read-only (`GET`), return JSON, and require no
authentication — this is a local single-user tool. All responses are
`Content-Type: application/json`.

---

## `GET /api/occupations`

Returns the full list of occupations, optionally filtered and sorted.

**Query parameters** (all optional):

| Param | Type | Description |
|---|---|---|
| `q` | string | Case-insensitive substring match on `title` |
| `category` | string | Exact match on `category` (see `/api/categories` for values) |
| `education` | string | Exact match on `typical_education` |
| `sort` | string | One of `demand_index` (default), `pct_change`, `median_wage`, `annual_openings`, `openings_rate_pct`, `title` |
| `dir` | string | `desc` (default) or `asc` |

**Example**

```
GET /api/occupations?category=Healthcare%20Practitioners%20%26%20Technical&sort=median_wage&dir=desc
```

**Response** — array of occupation objects:

```json
[
  {
    "soc_code": "29-1141",
    "title": "Registered nurses",
    "category": "Healthcare Practitioners & Technical",
    "employment_start": 3391.0,
    "employment_end": 3557.1,
    "period": "2024-2034",
    "pct_change": 4.9,
    "annual_openings": 189.1,
    "openings_rate_pct": 5.6,
    "median_wage": 93600,
    "wage_topcoded": 0,
    "typical_education": "Bachelor's degree",
    "work_experience": "None",
    "on_job_training": "None",
    "growth_score": 41.5,
    "openings_score": 27.9,
    "demand_index": 34.0
  }
]
```

`wage_topcoded` is `1` when BLS reports the wage as `>=$239,200` (its
published ceiling) rather than an exact figure — `median_wage` will be
`239200` in that case and the true figure is higher. `median_wage` is
`null` for the small number of occupations (mostly performing artists)
where BLS doesn't publish a wage.

---

## `GET /api/occupation/<soc_code>`

Single occupation lookup by SOC code (URL-encode the slash-free code,
e.g. `29-1141`).

```
GET /api/occupation/29-1141
```

Returns the same object shape as above, or `404 {"error": "not found"}`.

---

## `GET /api/categories`

Returns each of the 22 major SOC groups with a count and average Demand
Index — used to populate the category filter dropdown.

```json
[
  {"category": "Healthcare Practitioners & Technical", "n": 71, "avg_demand": 42.3}
]
```

---

## `GET /api/education-levels`

Returns the distinct set of `typical_education` values present in the
dataset (used to populate the education filter dropdown).

```json
[
  {"typical_education": "Associate's degree"},
  {"typical_education": "Bachelor's degree"}
]
```

---

## Error handling

All endpoints return `200` on success. The only documented error is the
`404` on `/api/occupation/<soc_code>` for an unknown code. Malformed
`sort` values silently fall back to `demand_index` rather than erroring.

## Extending this API

This is intentionally minimal. If you build on it, natural next
endpoints: `POST /api/compare` (multi-occupation comparison),
`GET /api/occupations/<soc_code>/related` (O*NET-style related
occupations), or pagination (`limit`/`offset`) once the UI needs it —
832 rows is small enough that the current app sends the full set today.
