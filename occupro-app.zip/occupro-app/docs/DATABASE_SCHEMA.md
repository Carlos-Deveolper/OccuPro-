# Database Schema

`career_demand.db` is a single-table SQLite database, rebuilt from
scratch each time `build_database.py` runs (it's a derived artifact, not
something you hand-edit).

## Table: `occupations`

| Column | Type | Description |
|---|---|---|
| `soc_code` | `TEXT` (PK) | Standard Occupational Classification code, e.g. `29-1141` |
| `title` | `TEXT` | Occupation title as published by BLS |
| `category` | `TEXT` | One of the 22 major SOC groups (2-digit SOC prefix) |
| `employment_start` | `REAL` | Employment at the start of the projection window, thousands |
| `employment_end` | `REAL` | Projected employment at the end of the window, thousands |
| `period` | `TEXT` | The 10-year window, e.g. `2024-2034` |
| `pct_change` | `REAL` | Projected % employment change over the period |
| `annual_openings` | `REAL` | BLS "occupational openings, annual average," thousands — includes both growth and replacement needs |
| `openings_rate_pct` | `REAL` | Computed: `annual_openings / employment_start`, as a percent |
| `median_wage` | `INTEGER`, nullable | Median annual wage, USD. `NULL` when BLS doesn't publish one (mostly performing-arts occupations) |
| `wage_topcoded` | `INTEGER` (0/1) | `1` if BLS reported the wage as `>=$239,200` (its ceiling) rather than an exact number |
| `typical_education` | `TEXT` | Typical education needed for entry (BLS's own category) |
| `work_experience` | `TEXT` | Work experience in a related occupation typically needed |
| `on_job_training` | `TEXT` | Typical on-the-job training needed to reach competency |
| `growth_score` | `REAL` | 0–100, the growth component of the Demand Index (see `demand_calculator.py`) |
| `openings_score` | `REAL` | 0–100, the openings-rate component of the Demand Index |
| `demand_index` | `REAL` | 0–100, `0.45 * growth_score + 0.55 * openings_score` |

**Indexes:** `idx_category` on `category`, `idx_demand` on `demand_index`
(both support the app's common filter/sort queries).

## Entity-relationship diagram

There's only one table — no joins, no foreign keys. If this grows to
support regional data or historical BLS cycles, the natural normalization
is:

```mermaid
erDiagram
    OCCUPATIONS ||--o{ REGIONAL_WAGES : "would reference"
    OCCUPATIONS ||--o{ PROJECTION_CYCLES : "would reference"
    OCCUPATIONS {
        text soc_code PK
        text title
        text category
        real employment_start
        real employment_end
        text period
        real pct_change
        real annual_openings
        real openings_rate_pct
        integer median_wage
        integer wage_topcoded
        text typical_education
        text work_experience
        text on_job_training
        real growth_score
        real openings_score
        real demand_index
    }
    REGIONAL_WAGES {
        text soc_code FK
        text state
        integer median_wage
    }
    PROJECTION_CYCLES {
        text soc_code FK
        text period
        real pct_change
        real annual_openings
    }
```

`REGIONAL_WAGES` and `PROJECTION_CYCLES` are **not implemented** — they're
shown to illustrate where regional data or multi-cycle trend data would
plug in if you add them (see the "Regional demand" link-out in the app
for where to source that data today).

## Rebuilding

```bash
python data/build_from_bls_xlsx.py   # xlsx -> data/occupations.json
python build_database.py             # json -> career_demand.db
```

Both are idempotent — safe to re-run any time the source workbook changes.
