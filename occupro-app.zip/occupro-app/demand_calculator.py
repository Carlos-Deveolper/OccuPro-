"""
demand_calculator.py

Turns raw BLS Employment Projections figures into a single, comparable
"Career Demand Index" (0-100) for each occupation.

IMPORTANT: this index is NOT an official BLS statistic. BLS does not
publish a single "likelihood you'll get a job" number - it publishes
employment levels, projected growth, and annual openings. This module
combines two of those real, government-published numbers into one
score so occupations can be compared side by side. Treat it as a
directional planning signal, not a guarantee.

The two ingredients:

1. Growth score - how fast the field is expanding (BLS "% employment
   change" over the projection decade). A shrinking field drags this
   toward 0; a fast-growing one pushes it toward 100.

2. Openings score - how many positions open up each year *relative to
   the current size of the field* (BLS "annual average occupational
   openings" divided by current employment). This captures something
   growth alone misses: even a field with flat growth can have huge
   turnover (e.g. lots of retirements), which means lots of real
   openings for a new entrant. Conversely a fast-growing but tiny or
   low-turnover field may not open many actual seats per year.

Demand Index = 0.45 * growth_score + 0.55 * openings_score

Openings rate is weighted slightly higher because it's the more direct
answer to "how likely is a position to be available to me" - growth
rate alone can be misleading for small-but-fast-growing fields.
"""

from __future__ import annotations
from dataclasses import dataclass

# Calibration bounds. These map real-world BLS ranges onto 0-100.
# Growth: -20% (contracting field) to +40% (exceptionally fast, e.g.
# veterinarians at 46%, home health aides at 20.7%) covers the vast
# majority of occupations without letting one outlier compress the scale.
GROWTH_FLOOR = -20.0
GROWTH_CEIL = 40.0

# Openings rate = annual openings / current employment. Occupations with
# high turnover (retail, food service, home health aides) can exceed
# 15-20% annually; stable professional fields often sit at 4-8%.
OPENINGS_FLOOR = 0.0
OPENINGS_CEIL = 0.20

GROWTH_WEIGHT = 0.45
OPENINGS_WEIGHT = 0.55


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _scale(value: float, floor: float, ceil: float) -> float:
    """Linearly map value in [floor, ceil] to [0, 100], clamped."""
    if ceil == floor:
        return 0.0
    pct = (value - floor) / (ceil - floor) * 100
    return _clamp(pct, 0.0, 100.0)


@dataclass
class DemandResult:
    growth_score: float
    openings_score: float
    openings_rate: float
    demand_index: float


def calculate_demand(pct_change: float, annual_openings: float,
                      employment_start: float) -> DemandResult:
    """
    pct_change: BLS projected % employment change over the decade
    annual_openings: BLS annual average occupational openings (thousands)
    employment_start: employment at the start of the projection window (thousands)
    """
    growth_score = _scale(pct_change, GROWTH_FLOOR, GROWTH_CEIL)

    openings_rate = (annual_openings / employment_start) if employment_start else 0.0
    openings_score = _scale(openings_rate, OPENINGS_FLOOR, OPENINGS_CEIL)

    demand_index = round(GROWTH_WEIGHT * growth_score + OPENINGS_WEIGHT * openings_score, 1)

    return DemandResult(
        growth_score=round(growth_score, 1),
        openings_score=round(openings_score, 1),
        openings_rate=round(openings_rate * 100, 1),  # as a percent
        demand_index=demand_index,
    )


def demand_label(demand_index: float) -> str:
    """A short human-readable label for a demand index value."""
    if demand_index >= 75:
        return "Very high demand"
    if demand_index >= 55:
        return "High demand"
    if demand_index >= 35:
        return "Moderate demand"
    if demand_index >= 15:
        return "Low demand"
    return "Very low demand"
