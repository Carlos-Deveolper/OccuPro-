# OccuPro — Career Demand Explorer

A database of **~830 U.S. job fields** — the BLS's full detailed occupation
matrix — with a transparent "Demand Index" (0–100) computed from real
Bureau of Labor Statistics Employment Projections data. Built to help you
weigh a career's growth outlook and typical entry education before
committing years to it.

![Navy #0A2540, Royal Blue #2563EB, Emerald #10B981](https://img.shields.io/badge/palette-navy%20%7C%20royal%20blue%20%7C%20emerald-2563EB)

**v2 additions:** compare up to 4 careers side by side, print a career or
comparison, an experience-vs-salary chart, a full legal disclaimer, and a
mobile-first redesign (touch-sized controls, card layout, filter drawer,
toast notifications, loading states, and pagination for smooth scrolling
through 830+ rows).

---

## 1. Installation

**Requirements:** Python 3.9+ and `pip`. No database server, no build
tools, nothing else to install system-wide.

```bash
# 1. Unzip the package and enter it
cd occupro-app

# 2. Install the one dependency (Flask)
pip install flask pandas openpyxl

# 3. Build the database from the included dataset
python build_database.py

# 4. Run the app
python app.py
```

Then open **http://127.0.0.1:5000** in your browser. That's the whole
install — steps 2-4 take under a minute.

Prefer zero setup entirely? Skip all of that and just open
`occupro-explorer.html` (in this same folder) directly in any browser —
see [Live demo](#2-live-demo) below.

**Optional — git:**
```bash
git init && git add -A && git commit -m "Initial commit: OccuPro v1.0"
```
(A repo is already initialized in this package — see [Version control](#7-version-control).)

---

## 2. Live demo

This runs entirely on your machine — nothing here is hosted on the
public internet, so there's no live URL to click. Two ways to get a
"demo" running in under a minute:

- **Zero-install demo:** open **`occupro-explorer.html`** directly in
  any browser (double-click it, or `open occupro-explorer.html` /
  `start occupro-explorer.html`). The full ~830-occupation dataset is
  embedded in the file — it works offline, no server, no dependencies.
- **Full app demo:** follow the [Installation](#1-installation) steps
  above (`pip install`, `python build_database.py`, `python app.py`) —
  three commands, then it's live at `http://127.0.0.1:5000`.

**If you want a real public URL:** the cleanest free option is deploying
`app.py` to [Render](https://render.com) or [Railway](https://railway.app)
(both have free tiers and auto-detect Flask apps from `requirements.txt`),
or publishing `occupro-explorer.html` alone to **GitHub Pages** (Settings →
Pages → deploy from the `main` branch — since it's one static file with
everything embedded, no build step is needed). Doing this requires your
own GitHub/hosting account, so it isn't something built into this package
— but either path is a few clicks once the repo is pushed.

---

## 3. What's included

| File / folder | What it does |
|---|---|
| `data/source/BLS_occupation_info.xlsx` | The official BLS workbook this dataset is parsed from |
| `data/build_from_bls_xlsx.py` | Parses the workbook into `data/occupations.json` |
| `data/occupations.json` | The full dataset — ~830 detailed occupations |
| `data/seed_data.py` | Thin loader, exposes `OCCUPATIONS` from the JSON |
| `data/build_standalone.py` | Regenerates `occupro-explorer.html` |
| `demand_calculator.py` | The Demand Index formula — pure Python, no dependencies |
| `build_database.py` | Builds `career_demand.db` (SQLite) |
| `cli.py` | Command-line tool to query the database |
| `app.py` + `templates/` + `static/` | Flask web app: search, filter, sort, pagination, compare up to 4 careers, print, experience-vs-salary chart, detail modal, legal disclaimer |
| `occupro-explorer.html` | Standalone build — all data embedded, opens with no server |
| `docs/ARCHITECTURE.md` | System architecture + diagram |
| `docs/API.md` | REST API reference |
| `docs/DATABASE_SCHEMA.md` | Database schema + ER diagram |

---

## 4. Command line

```bash
python cli.py top                          # highest-demand careers
python cli.py search nurse                  # search by title
python cli.py category "Healthcare Support"
python cli.py education "Bachelor's degree"
python cli.py show 29-1141                  # full detail by SOC code
```

---

## 5. Data source

The full dataset is parsed directly from the **official BLS workbook**
(`data/source/BLS_occupation_info.xlsx`) — the 2024 National Employment
Matrix, "Occupational projections and worker characteristics" table
(Table 1.2 of the Employment Projections release), 2024–2034 cycle. It
includes every one of BLS's ~830 detailed "line item" occupations across
all 22 major SOC groups — this is BLS's actual full matrix, not a sample.

To refresh with a newer BLS release: replace the workbook in
`data/source/`, then run `python data/build_from_bls_xlsx.py` and
`python build_database.py`.

---

## 6. How the Demand Index works

BLS does not publish a single "likelihood you'll get hired" number. This
tool builds one from two real BLS figures, weighted:

```
Demand Index = 0.45 × growth_score + 0.55 × openings_score
```

- **growth_score** — projected 10-year % employment change, scaled so −20%
  (contracting) maps to 0 and +40% (exceptional growth) maps to 100.
- **openings_score** — BLS's "annual average occupational openings" divided
  by current employment, scaled so 0% maps to 0 and 20%+ maps to 100.

**Important caveat:** a high score can come from genuine field growth *or*
from high turnover in a large, low-barrier field. Always read it next to
wage and typical education, not in isolation. It's a directional planning
signal, not a guarantee — and it says nothing about your local job market
or individual qualifications.

### What the detail panel does — and doesn't — include

Click "Details" on any occupation for the full BLS breakdown plus links
to real external sources. We were asked to add several additional data
points and want to be upfront about which ones made it in with real data
and which didn't, rather than inventing numbers for a tool people might
use to make real decisions:

| Requested | Status | Why |
|---|---|---|
| Required certifications | **Linked, not fabricated** | No certifications column exists in the BLS dataset. The detail panel links to O*NET's real per-occupation profile and CareerOneStop's Certification Finder instead of a guessed list. |
| Regional demand | **Linked, not fabricated** | State-level BLS/CareerOneStop data exists but isn't in this workbook (it's a separate large dataset). Linked out rather than invented. |
| School ROI ranking / student debt vs. lifetime earnings | **Linked, not fabricated** | Ranking real, named schools with invented ROI numbers could actively mislead a real decision. The U.S. Dept. of Education's **College Scorecard** has real, government-published earnings and debt data by school and major — linked directly instead. |
| Graduate competition ("how many grads compete for these jobs") | **Linked, not fabricated** | This requires joining NCES completions data (IPEDS) by field of study to SOC codes — a real but separate dataset, not part of this BLS workbook. Linked to NCES IPEDS. |
| AI automation risk (10-year) | **Not included** | The commonly-cited figures trace back almost entirely to one 2013 academic study (Frey & Osborne) that's now over a decade old and was never an official government statistic. Presenting it as a per-occupation number here would lend it more authority than it deserves. Current, defensible automation-risk scoring exists mainly behind paid commercial tools (e.g. Lightcast). |
| Probability of hire within 6 months | **Not included** | No public dataset publishes this at occupation granularity — it doesn't exist as a real, sourceable number to show. The Demand Index is offered as the closest honest, sourced proxy. |
| Expected salary at graduation | **Partial** | BLS publishes wage *percentiles* (10th percentile approximates entry-level pay), but that's a separate table from the one used here. Only the median wage is currently included; percentile data is a natural next addition (see `docs/ARCHITECTURE.md`). |

---

## 7. Version control

This package includes a git repository with the full commit history of
its own build. To inspect it:

```bash
git log --oneline
```

To push it to your own remote:

```bash
git remote add origin <your-repo-url>
git push -u origin main
```

---

## 8. Documentation

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — system architecture + diagram
- [`docs/API.md`](docs/API.md) — REST API reference
- [`docs/DATABASE_SCHEMA.md`](docs/DATABASE_SCHEMA.md) — schema + ER diagram
