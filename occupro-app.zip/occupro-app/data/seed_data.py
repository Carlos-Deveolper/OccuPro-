"""
seed_data.py

Loads OCCUPATIONS from data/occupations.json — the full official BLS dataset
(832 detailed "line item" occupations, 2024 National Employment Matrix,
2024-2034 projection cycle), parsed directly from the BLS workbook by
build_from_bls_xlsx.py.

To refresh: replace data/source/BLS_occupation_info.xlsx with a newer BLS
download and re-run `python data/build_from_bls_xlsx.py`.
"""

import json
from pathlib import Path

_JSON_PATH = Path(__file__).parent / "occupations.json"

if not _JSON_PATH.exists():
    raise FileNotFoundError(
        "data/occupations.json not found. Run `python data/build_from_bls_xlsx.py` "
        "first (requires data/source/BLS_occupation_info.xlsx)."
    )

OCCUPATIONS = json.loads(_JSON_PATH.read_text())
