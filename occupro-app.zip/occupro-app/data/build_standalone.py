"""
build_standalone.py

Generates occupro-explorer.html — a single self-contained file with the
full dataset, logo, styles, and all interactive features (compare, print,
chart, disclaimer) embedded inline. Opens directly in any browser, works
fully offline.

Builds from the SAME sources as the Flask app (templates/index.html,
static/style.css, static/app.js) so the two builds can't drift apart —
only the data-loading tail of app.js differs (fetch calls vs. an
in-memory array), and that swap happens here automatically.

Usage:
    python data/build_standalone.py
"""

import base64
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
OUTPUT = ROOT / "occupro-explorer.html"
JS_SPLIT_MARKER = "/* ---------------------------- Data loading (overridden per build) ---------------------------- */"


def build():
    sys.path.insert(0, str(ROOT))
    from demand_calculator import calculate_demand

    occupations = json.loads((ROOT / "data" / "occupations.json").read_text())
    enriched = []
    for occ in occupations:
        r = calculate_demand(occ["pct_change"], occ["annual_openings"], occ["employment_start"])
        d = dict(occ)
        d["demand_index"] = r.demand_index
        d["growth_score"] = r.growth_score
        d["openings_score"] = r.openings_score
        d["openings_rate_pct"] = r.openings_rate
        enriched.append(d)
    data_js = json.dumps(enriched)

    css = (ROOT / "static" / "style.css").read_text()
    logo_bytes = (ROOT / "static" / "img" / "occupro-logo.jpeg").read_bytes()
    logo_data_uri = f"data:image/jpeg;base64,{base64.b64encode(logo_bytes).decode('ascii')}"

    # --- Assemble standalone JS: shared logic + swapped data-loading tail ---
    app_js = (ROOT / "static" / "app.js").read_text()
    shared_js, _tail = app_js.split(JS_SPLIT_MARKER)

    standalone_tail_js = """
/* ---------------------------- Data loading (standalone / embedded data) ---------------------------- */
function populateFilters() {
  const cats = {};
  const edus = new Set();
  ALL_ROWS.forEach(r => {
    cats[r.category] = (cats[r.category] || 0) + 1;
    edus.add(r.typical_education);
  });
  Object.keys(cats).sort().forEach(c => {
    const opt = document.createElement('option');
    opt.value = c;
    opt.textContent = `${c} (${cats[c]})`;
    els.category.appendChild(opt);
  });
  [...edus].sort().forEach(e => {
    const opt = document.createElement('option');
    opt.value = e;
    opt.textContent = e;
    els.education.appendChild(opt);
  });
}

function applyFilters() {
  renderSkeleton();
  setTimeout(() => {
    const q = els.search.value.trim().toLowerCase();
    const cat = els.category.value;
    const edu = els.education.value;
    const sortKey = els.sort.value;

    let rows = ALL_ROWS.filter(r => {
      if (q && !r.title.toLowerCase().includes(q)) return false;
      if (cat && r.category !== cat) return false;
      if (edu && r.typical_education !== edu) return false;
      return true;
    });

    rows.sort((a, b) => {
      if (sortKey === 'title') return a.title.localeCompare(b.title);
      const av = a[sortKey] == null ? -Infinity : a[sortKey];
      const bv = b[sortKey] == null ? -Infinity : b[sortKey];
      return bv - av;
    });

    renderRows(rows);
  }, 120);
}

function renderHeroStats() {
  const avgGrowth = ALL_ROWS.reduce((s, r) => s + r.pct_change, 0) / ALL_ROWS.length;
  const cats = new Set(ALL_ROWS.map(r => r.category));
  const nums = els.heroStats.querySelectorAll('.stat-num');
  nums[0].textContent = ALL_ROWS.length;
  nums[1].textContent = `${avgGrowth >= 0 ? '+' : ''}${avgGrowth.toFixed(1)}%`;
  nums[2].textContent = cats.length;
  renderExperienceChart(ALL_ROWS);
}

let searchDebounce;
els.search.addEventListener('input', () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(applyFilters, 200);
});
[els.category, els.education, els.sort].forEach(el => {
  el.addEventListener('change', applyFilters);
});

ALL_ROWS = OCCUPATIONS;
populateFilters();
renderHeroStats();
applyFilters();
"""

    standalone_js = f"const OCCUPATIONS = {data_js};\n" + shared_js + standalone_tail_js

    # --- Assemble standalone HTML from the same template as the Flask app ---
    html = (ROOT / "templates" / "index.html").read_text()

    html = html.replace(
        '<link rel="stylesheet" href="{{ url_for(\'static\', filename=\'style.css\') }}">',
        f"<style>\n{css}\n</style>",
    )
    html = html.replace(
        '<img class="brand-logo" src="{{ url_for(\'static\', filename=\'img/occupro-logo.jpeg\') }}" alt="OccuPro logo">',
        f'<img class="brand-logo" src="{logo_data_uri}" alt="OccuPro logo">',
    )
    html = html.replace(
        '<script src="{{ url_for(\'static\', filename=\'app.js\') }}"></script>',
        f"<script>\n{standalone_js}\n</script>",
    )
    html = html.replace(
        "<title>OccuPro — Career Demand Explorer, U.S. BLS Employment Projections</title>",
        "<title>OccuPro — Career Demand Explorer (offline build), U.S. BLS Employment Projections</title>",
    )
    html = html.replace(
        "Demand Index is a derived planning tool, not an official government statistic.",
        "Demand Index is a derived planning tool, not an official government statistic. "
        "This standalone file has the full dataset embedded and works fully offline.",
    )

    OUTPUT.write_text(html)
    print(f"Wrote {OUTPUT} ({len(html):,} bytes, {len(enriched)} occupations)")


if __name__ == "__main__":
    build()
