"""
build_from_bls_xlsx.py

Parses the official BLS "Occupational projections and worker characteristics"
workbook (Table 1.2 of the Employment Projections release) into
data/occupations.json — the full ~830-occupation dataset, replacing the
smaller hand-curated sample.

Source file: data/source/BLS_occupation_info.xlsx (user-provided, downloaded
directly from bls.gov/emp/data/occupational-data.htm — the 2024 National
Employment Matrix, 2024-2034 projection cycle).

Usage:
    python data/build_from_bls_xlsx.py
"""

import json
from pathlib import Path
import pandas as pd

SOURCE_XLSX = Path(__file__).parent / "source" / "BLS_occupation_info.xlsx"
OUTPUT_JSON = Path(__file__).parent / "occupations.json"

# BLS's own 22 major SOC occupational groups (2-digit prefix -> title).
MAJOR_GROUPS = {
    "11": "Management",
    "13": "Business & Financial Operations",
    "15": "Computer & Mathematical",
    "17": "Architecture & Engineering",
    "19": "Life, Physical & Social Science",
    "21": "Community & Social Service",
    "23": "Legal",
    "25": "Educational Instruction & Library",
    "27": "Arts, Design, Entertainment, Sports & Media",
    "29": "Healthcare Practitioners & Technical",
    "31": "Healthcare Support",
    "33": "Protective Service",
    "35": "Food Preparation & Serving",
    "37": "Building & Grounds Maintenance",
    "39": "Personal Care & Service",
    "41": "Sales & Related",
    "43": "Office & Administrative Support",
    "45": "Farming, Fishing & Forestry",
    "47": "Construction & Extraction",
    "49": "Installation, Maintenance & Repair",
    "51": "Production",
    "53": "Transportation & Material Moving",
}


def parse_wage(raw):
    """Returns (median_wage_int_or_None, wage_is_topcoded_bool)."""
    if isinstance(raw, (int, float)):
        return int(raw), False
    text = str(raw).strip()
    if text.startswith(">="):
        # BLS top-codes very high wages, e.g. ">=$239,200"
        return int(text.replace(">=", "").replace("$", "").replace(",", "")), True
    return None, False  # "—" : no wage published for this occupation


def clean_str(value, default="Not reported"):
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return default
    text = str(value).strip()
    return text if text and text != "—" else default


def build():
    df = pd.read_excel(SOURCE_XLSX, sheet_name="Table 1.2", header=1)
    line_items = df[df["Occupation type"] == "Line item"].copy()

    records = []
    for _, row in line_items.iterrows():
        soc = str(row["2024 National Employment Matrix code"]).strip()
        major = soc[:2]
        median_wage, wage_topcoded = parse_wage(row["Median annual wage, dollars, 2024[1]"])

        records.append(dict(
            soc_code=soc,
            title=str(row["2024 National Employment Matrix title"]).strip(),
            category=MAJOR_GROUPS.get(major, "Other"),
            employment_start=float(row["Employment, 2024"]),
            employment_end=float(row["Employment, 2034"]),
            period="2024-2034",
            pct_change=float(row["Employment change, percent, 2024\u201334"]),
            annual_openings=float(row["Occupational openings, 2024\u201334 annual average"]),
            median_wage=median_wage,
            wage_topcoded=wage_topcoded,
            typical_education=clean_str(row["Typical education needed for entry"]),
            work_experience=clean_str(row["Work experience in a related occupation"], default="None"),
            on_job_training=clean_str(
                row["Typical on-the-job training needed to attain competency in the occupation"],
                default="None",
            ),
        ))

    OUTPUT_JSON.write_text(json.dumps(records, indent=1))
    print(f"Wrote {len(records)} occupations to {OUTPUT_JSON}")

    # Quick sanity summary
    by_cat = {}
    for r in records:
        by_cat[r["category"]] = by_cat.get(r["category"], 0) + 1
    for cat, n in sorted(by_cat.items()):
        print(f"  {cat}: {n}")


if __name__ == "__main__":
    build()
